<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rto_detalle', function (Blueprint $table) {
            $table->id();
            $table->foreignId('rto_id')->constrained('rto');
            $table->foreignId('elementoRto_id')->constrained('elementos_rto');
            $table->decimal('valorDolaresRtoTeorico', 10, 2)->nullable();
            $table->decimal('valorPesosRtoTeorico', 10, 2)->nullable();
            $table->decimal('TC_RtoTeorico', 10, 2)->nullable();
            $table->decimal('subTotalRtoTeorico', 10, 2);
            $table->decimal('valorPesosRtoReal', 10, 2)->nullable();
            $table->decimal('TC_RtoReal', 10, 2)->nullable();
            $table->decimal('subTotalRtoReal', 10, 2)->nullable();          
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rto_detalle');
    }
};
