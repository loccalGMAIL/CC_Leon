@extends('layouts.main')

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Informes</h1>
      
    </div><!-- End Page Title -->

    <section class="section dashboard">

    </section>

  </main>