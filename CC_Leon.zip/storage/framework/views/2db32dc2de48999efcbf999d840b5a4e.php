<?php $__env->startSection('titulo', $titulo); ?>
<?php $__env->startSection('contenido'); ?>
  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Reclamos</h1>
      <?php if(isset($remito)): ?>
        <nav>
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('remitos')); ?>">Remitos</a></li>
            <li class="breadcrumb-item active">Reclamos del Remito <?php echo e(str_pad($remito->id, 6, '0', STR_PAD_LEFT)); ?></li>
          </ol>
        </nav>
      <?php endif; ?>
    </div><!-- End Page Title -->
   
    <section class="section">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <?php if(isset($remito)): ?>
                <h5 class="card-title">
                  Reclamos del Remito #<?php echo e(str_pad($remito->proveedores_id, 3, '0', STR_PAD_LEFT)); ?>-<?php echo e(str_pad($remito->camion, 3, '0', STR_PAD_LEFT)); ?>-<?php echo e(str_pad($remito->id, 6, '0', STR_PAD_LEFT)); ?>

                </h5>
                <p>Proveedor: <?php echo e($remito->proveedor->razonSocialProveedor); ?></p>
                <p>Factura: <?php echo e($remito->nroFacturaRto); ?></p>
               
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h5>Lista de Reclamos</h5>
                  <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#agregarReclamoModal">
                    <i class="fa-solid fa-circle-plus"></i> Agregar Reclamo
                  </a>
                </div>
              <?php else: ?>
                <h5 class="card-title">Administrar los reclamos</h5>
                <p class="card-text">En esta sección podrá administrar los reclamos de los envios.</p>
              <?php endif; ?>
             
              <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <?php echo e(session('success')); ?>

                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
              <?php endif; ?>
              
              <!-- Table with datatable -->
              <table class="table datatable">
                <thead>
                  <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">Fecha</th>
                    <?php if(!isset($remito)): ?>
                      <th class="text-center">Nro Remito</th>
                    <?php endif; ?>
                    <th class="text-center">Proveedor</th>
                    <th class="text-center">Producto</th>
                    <th class="text-center">Cantidad</th>
                    <th class="text-center">Observaciones</th>
                    <th class="text-center">Estado</th>
                    <th class="text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                      <td><?php echo e($item->id); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i')); ?></td>
                      <?php if(!isset($remito)): ?>
                        <td><?php echo e(str_pad($item->Rto_id, 6, '0', STR_PAD_LEFT)); ?></td>
                      <?php endif; ?>
                      <td><?php echo e($item->rto->proveedor->razonSocialProveedor); ?></td>
                      <td><?php echo e($item->producto); ?></td>
                      <td><?php echo e($item->cantidad); ?></td>
                      <td><?php echo e(Str::limit($item->observaciones, 30)); ?></td>
                      <td>
                        <span class="badge <?php echo e($item->estadoReclamoRto == 'pendiente' ? 'bg-warning' : 'bg-success'); ?>">
                          <?php echo e(ucfirst($item->estadoReclamoRto)); ?>

                        </span>
                      </td>
                      <td>
                        <a href="#" class="badge bg-success" data-bs-toggle="modal" data-bs-target="#editarReclamoModal<?php echo e($item->id); ?>" title="Editar">
                          <i class="fa-solid fa-pen-to-square"></i></a>
                        <a href="#" class="badge bg-danger" onclick="confirmarEliminar(<?php echo e($item->id); ?>)" title="Eliminar">
                          <i class="fa-solid fa-trash"></i></a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <!-- End Table with datatable -->
              
              <?php if($items->isEmpty()): ?>
                <div class="alert alert-info mt-3">No hay reclamos registrados<?php echo e(isset($remito) ? ' para este remito' : ''); ?>.</div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </section>
   
    <?php if(isset($remito)): ?>
    <!-- Modal para agregar reclamo -->
    <div class="modal fade" id="agregarReclamoModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Agregar Reclamo</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="nuevoReclamoForm" method="POST" action="<?php echo e(route('reclamos.store')); ?>">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="Rto_id" value="<?php echo e($remito->id); ?>">
              
              <div class="row mb-3">
                <label for="producto" class="col-sm-3 col-form-label">Producto</label>
                <div class="col-sm-9">
                  <input type="text" class="form-control" id="producto" name="producto" required>
                </div>
              </div>
              
              <div class="row mb-3">
                <label for="cantidad" class="col-sm-3 col-form-label">Cantidad</label>
                <div class="col-sm-9">
                  <input type="number" class="form-control" id="cantidad" name="cantidad" step="0.01" required>
                </div>
              </div>
              
              <div class="row mb-3">
                <label for="observaciones" class="col-sm-3 col-form-label">Observaciones</label>
                <div class="col-sm-9">
                  <textarea class="form-control" id="observaciones" name="observaciones" rows="3" required></textarea>
                </div>
              </div>
              
              <div class="row mb-3">
                <label for="estadoReclamoRto" class="col-sm-3 col-form-label">Estado</label>
                <div class="col-sm-9">
                  <select class="form-select" id="estadoReclamoRto" name="estadoReclamoRto" required onchange="toggleResolucionField('nuevo')">
                    <option value="pendiente">Pendiente</option>
                    <option value="resuelto">Resuelto</option>
                  </select>
                </div>
              </div>
              
              <div class="row mb-3" id="resolucionContainer" style="display: none;">
                <label for="resolucionReclamoRto" class="col-sm-3 col-form-label">Resolución</label>
                <div class="col-sm-9">
                  <textarea class="form-control" id="resolucionReclamoRto" name="resolucionReclamoRto" rows="3"></textarea>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" form="nuevoReclamoForm" class="btn btn-primary">Guardar</button>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
   
    <!-- Modales para editar cada reclamo -->
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="modal fade" id="editarReclamoModal<?php echo e($item->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Editar Reclamo</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <form id="editarReclamoForm<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('reclamos.update', $item->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row mb-3">
                  <label for="edit_producto_<?php echo e($item->id); ?>" class="col-sm-3 col-form-label">Producto</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="edit_producto_<?php echo e($item->id); ?>" name="producto" value="<?php echo e($item->producto); ?>" required>
                  </div>
                </div>
                
                <div class="row mb-3">
                  <label for="edit_cantidad_<?php echo e($item->id); ?>" class="col-sm-3 col-form-label">Cantidad</label>
                  <div class="col-sm-9">
                    <input type="number" class="form-control" id="edit_cantidad_<?php echo e($item->id); ?>" name="cantidad" value="<?php echo e($item->cantidad); ?>" step="0.01" required>
                  </div>
                </div>
                
                <div class="row mb-3">
                  <label for="edit_observaciones_<?php echo e($item->id); ?>" class="col-sm-3 col-form-label">Observaciones</label>
                  <div class="col-sm-9">
                    <textarea class="form-control" id="edit_observaciones_<?php echo e($item->id); ?>" name="observaciones" rows="3" required><?php echo e($item->observaciones); ?></textarea>
                  </div>
                </div>
                
                <div class="row mb-3">
                  <label for="edit_estado_<?php echo e($item->id); ?>" class="col-sm-3 col-form-label">Estado</label>
                  <div class="col-sm-9">
                    <select class="form-select" 
                            id="edit_estado_<?php echo e($item->id); ?>" 
                            name="estadoReclamoRto" 
                            onchange="toggleResolucionField('<?php echo e($item->id); ?>')"
                            required>
                      <option value="pendiente" <?php echo e($item->estadoReclamoRto == 'pendiente' ? 'selected' : ''); ?>>Pendiente</option>
                      <option value="resuelto" <?php echo e($item->estadoReclamoRto == 'resuelto' ? 'selected' : ''); ?>>Resuelto</option>
                    </select>
                  </div>
                </div>
                
                <div class="row mb-3" id="resolucion_container_<?php echo e($item->id); ?>" style="<?php echo e($item->estadoReclamoRto == 'resuelto' ? 'display: block;' : 'display: none;'); ?>">
                  <label for="edit_resolucion_<?php echo e($item->id); ?>" class="col-sm-3 col-form-label">Resolución</label>
                  <div class="col-sm-9">
                    <textarea class="form-control" 
                             id="edit_resolucion_<?php echo e($item->id); ?>" 
                             name="resolucionReclamoRto" 
                             rows="3" 
                             <?php echo e($item->estadoReclamoRto == 'resuelto' ? 'required' : ''); ?>><?php echo e($item->resolucionReclamoRto); ?></textarea>
                  </div>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" form="editarReclamoForm<?php echo e($item->id); ?>" class="btn btn-primary">Actualizar</button>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    <script>
      function confirmarEliminar(id) {
        if (confirm('¿Está seguro que desea eliminar este reclamo?')) {
          // Crear un formulario dinámicamente para enviar la solicitud DELETE
          const form = document.createElement('form');
          form.method = 'POST';
          form.action = '<?php echo e(url("reclamos/delete")); ?>/' + id;
          form.style.display = 'none';
         
          const csrfToken = document.createElement('input');
          csrfToken.type = 'hidden';
          csrfToken.name = '_token';
          csrfToken.value = '<?php echo e(csrf_token()); ?>';
         
          const method = document.createElement('input');
          method.type = 'hidden';
          method.name = '_method';
          method.value = 'DELETE';
         
          form.appendChild(csrfToken);
          form.appendChild(method);
          document.body.appendChild(form);
          form.submit();
        }
      }
      
      function toggleResolucionField(id) {
        const isNuevo = id === 'nuevo';
        const estadoSelect = isNuevo ? 
                            document.getElementById('estadoReclamoRto') : 
                            document.getElementById(`edit_estado_${id}`);
        const resolucionContainer = isNuevo ? 
                                  document.getElementById('resolucionContainer') : 
                                  document.getElementById(`resolucion_container_${id}`);
        const resolucionTextarea = isNuevo ? 
                                 document.getElementById('resolucionReclamoRto') : 
                                 document.getElementById(`edit_resolucion_${id}`);
        
        if (estadoSelect.value === 'resuelto') {
          resolucionContainer.style.display = 'block';
          resolucionTextarea.setAttribute('required', 'required');
        } else {
          resolucionContainer.style.display = 'none';
          resolucionTextarea.removeAttribute('required');
        }
      }
    </script>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/modules/rto/reclamos/index.blade.php ENDPATH**/ ?>