
<?php $__env->startSection('titulo', $titulo); ?>
<?php $__env->startSection('contenido'); ?>
  <main id="main" class="main">
    <div class="pagetitle">
    <h1>Proveedores - Camiones</h1>
    </div><!-- End Page Title -->

    <section class="section">
    <div class="row">
      <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
        <h5 class="card-title">Agregar nuevo camión</h5>

        <form action="<?php echo e(route('proveedores.camiones.update', $item->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <div class="row g-3 mb-4">
          <!-- Primera columna -->
          <div class="col-md-6">
            <div class="form-group mb-3">
            <label for="patente" class="form-label">Patente del Camión</label>
            <input type="text" class="form-control" name="patente" id="patente" value="<?php echo e($item->patente); ?>">
            </div>


            <!-- Segunda columna -->
            <div class="col-md-6">
            <label for="proveedor_id">Proveedor</label>
            <select name="proveedor_id" id="proveedor_id" class="form-control">
                <option value=""></option>
                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($proveedor->id); ?>" <?php echo e($item->proveedores_id == $proveedor->id ? 'selected' : ''); ?>>
                    <?php echo e($proveedor->nombreProveedor); ?>

                  </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

            </div>
          </div>

          <div class="row mt-4">
            <div class="col-12">
            <div class="d-flex gap-2">
              <button type="submit" class="btn btn-primary">Guardar</button>
              <a href="<?php echo e(route('proveedores')); ?>" class="btn btn-info">Cancelar</a>
            </div>
            </div>
          </div>
        </form>

        </div>
      </div>
      </div>
    </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/modules/proveedores/camiones/edit.blade.php ENDPATH**/ ?>