<?php $__env->startSection('titulo', $titulo); ?>
<?php $__env->startSection('contenido'); ?>
  <main id="main" class="main">
    <div class="pagetitle">
    <h1>Observaciones</h1>
    <?php if(isset($remito)): ?>
    <nav>
      <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('remitos')); ?>">Remitos</a></li>
      <li class="breadcrumb-item active">Observaciones del Remito <?php echo e(str_pad($remito->id, 6, '0', STR_PAD_LEFT)); ?>

      </li>
      </ol>
    </nav>
  <?php endif; ?>
    </div><!-- End Page Title -->

    <section class="section">
    <div class="row">
      <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
        <?php if(isset($remito)): ?>
      <h5 class="card-title">
        Observaciones del Remito
        #<?php echo e(str_pad($remito->proveedores_id, 3, '0', STR_PAD_LEFT)); ?>-<?php echo e(str_pad($remito->camion, 3, '0', STR_PAD_LEFT)); ?>-<?php echo e(str_pad($remito->id, 6, '0', STR_PAD_LEFT)); ?>

      </h5>
      <p>Proveedor: <?php echo e($remito->proveedor->razonSocialProveedor); ?></p>
      <p>Factura: <?php echo e($remito->nroFacturaRto); ?></p>

      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Lista de Observaciones</h5>
        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#agregarObservacionModal">
        <i class="fa-solid fa-circle-plus"></i> Agregar Observación
        </a>
      </div>
    <?php else: ?>
    <h5 class="card-title">Administrar las observaciones</h5>
    <p class="card-text">En esta sección podrá administrar las observaciones de los envios.</p>
  <?php endif; ?>

        <?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>
        <!-- Table with stripped rows -->
        <table class="table datatable">
          <thead>
          <tr>
            <th class="text-center">#</th>
            <th class="text-center">Fecha</th>
            <?php if(!isset($remito)): ?>
        <th class="text-center">Nro Remito</th>
      <?php endif; ?>
            <th class="text-center">Proveedor</th>
            <th class="text-center">Descripcion</th>
            <th class="text-center">Acciones</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="text-center">
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i')); ?></td>
        <?php if(!isset($remito)): ?>
      <td><?php echo e(str_pad($item->Rto_id, 6, '0', STR_PAD_LEFT)); ?></td>
    <?php endif; ?>
        <td><?php echo e($item->rto->proveedor->razonSocialProveedor); ?></td>
        <td><?php echo e($item->descripcionObservacionesRto); ?></td>
        <td>
        <a href="#" class="badge bg-success" data-bs-toggle="modal"
          data-bs-target="#editarObservacionModal<?php echo e($item->id); ?>" title="Editar">
          <i class="fa-solid fa-pen-to-square"></i></a>
        <a href="#" class="badge bg-danger" onclick="confirmarEliminar(<?php echo e($item->id); ?>)" title="Eliminar">
          <i class="fa-solid fa-trash"></i></a>
        </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <!-- End Table with stripped rows -->

        <?php if($items->isEmpty()): ?>
      <div class="alert alert-info mt-3">No hay observaciones
        registradas<?php echo e(isset($remito) ? ' para este remito' : ''); ?>.</div>
    <?php endif; ?>
        </div>
      </div>
      </div>
    </div>
    </section>

    <?php if(isset($remito)): ?>
    <!-- Modal para agregar observación -->
    <div class="modal fade" id="agregarObservacionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
      <div class="modal-header">
      <h5 class="modal-title">Agregar Observación</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form id="nuevaObservacionForm" method="POST" action="<?php echo e(route('observaciones.store')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="Rto_id" value="<?php echo e($remito->id); ?>">
      <div class="mb-3">
        <label for="descripcionObservacionesRto" class="form-label">Descripción</label>
        <textarea class="form-control" id="descripcionObservacionesRto" name="descripcionObservacionesRto"
        rows="4" required></textarea>
      </div>
      </form>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button type="submit" form="nuevaObservacionForm" class="btn btn-primary">Guardar</button>
      </div>
      </div>
    </div>
    </div>
  <?php endif; ?>

    <!-- Modales para editar cada observación -->
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="editarObservacionModal<?php echo e($observacion->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
      <div class="modal-header">
      <h5 class="modal-title">Editar Observación</h5>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form id="editarObservacionForm<?php echo e($observacion->id); ?>" method="POST"
      action="<?php echo e(route('observaciones.update', $observacion->id)); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="mb-3">
        <label for="descripcionObservacionesRto<?php echo e($observacion->id); ?>" class="form-label">Descripción</label>
        <textarea class="form-control" id="descripcionObservacionesRto<?php echo e($observacion->id); ?>"
        name="descripcionObservacionesRto" rows="4"
        required><?php echo e($observacion->descripcionObservacionesRto); ?></textarea>
      </div>
      </form>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
      <button type="submit" form="editarObservacionForm<?php echo e($observacion->id); ?>"
      class="btn btn-primary">Actualizar</button>
      </div>
      </div>
    </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
    function confirmarEliminar(id) {
      if (confirm('¿Está seguro que desea eliminar esta observación?')) {
      // Crear un formulario dinámicamente para enviar la solicitud DELETE
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = '<?php echo e(url("observaciones/delete")); ?>/' + id;
      form.style.display = 'none';

      const csrfToken = document.createElement('input');
      csrfToken.type = 'hidden';
      csrfToken.name = '_token';
      csrfToken.value = '<?php echo e(csrf_token()); ?>';

      const method = document.createElement('input');
      method.type = 'hidden';
      method.name = '_method';
      method.value = 'DELETE';

      form.appendChild(csrfToken);
      form.appendChild(method);
      document.body.appendChild(form);
      form.submit();
      }
    }
    </script>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/modules/rto/observaciones/index.blade.php ENDPATH**/ ?>