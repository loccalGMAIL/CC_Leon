<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

  <main id="main" class="main">

    <div class="pagetitle">
    <h1>Proveedores</h1>

    </div><!-- End Page Title -->

    <section class="section">
    <div class="row">
      <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
        <h5 class="card-title">Administrar los proveedores</h5>
        <p class="card-text">En esta sección podrá administrar las cuentas de los proveedores.</p>

        <a href="<?php echo e(route('proveedores.create')); ?>" class="btn btn-primary mt-3 mb-3">
          <i class="fa-solid fa-circle-plus"> </i> Agregar nuevo proveedor
        </a>
        <!-- Table with stripped rows -->
        <table class="table datatable">
          <thead>
          <tr>
            <th></th>
            <th class="text-center">Nombre</th>
            <th class="text-center">DNI</th>
            <th class="text-center">Razon Social</th>
            <th class="text-center">CUIT</th>
            <th class="text-center">Direccion</th>
            <th class="text-center">Telefono</th>
            <th class="text-center">Email</th>
            <th class="text-center">Activo</th>
            <th class="text-center">Acciones</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="text-center">
            <td><?php echo e($item->id); ?></td>
          <td><?php echo e($item->nombreProveedor); ?></td>
          <td><?php echo e($item->dniProveedor); ?></td>
          <td><?php echo e($item->razonSocialProveedor); ?></td>
          <td><?php echo e($item->cuitProveedor); ?></td>
          <td><?php echo e($item->direccionProveedor); ?></td>
          <td><?php echo e($item->telefonoProveedor); ?></td>
          <td><?php echo e($item->mailProveedor); ?></td>
          <td><?php echo $item->estadoProveedor ? '<div class="form-check form-switch text-center">
        <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" checked>
        </div>' :
      '<div class="form-check form-switch text-center">
        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
        </div>'; ?></td>
          <td>
          <a href="<?php echo e(route('proveedores.edit', $item->id)); ?>" class="btn btn-warning bt-sm"><i class="fa-solid fa-user-pen"></i></a>
          </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <!-- End Table with stripped rows -->

        </div>
      </div>

      </div>
    </div>
    </section>

  </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/modules/proveedores/index.blade.php ENDPATH**/ ?>