<main id="main" class="main">

    <div class="pagetitle">
      <h1>Informes</h1>
      
    </div><!-- End Page Title -->

    <section class="section dashboard">

    </section>

  </main>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/modules/informes/index.blade.php ENDPATH**/ ?>