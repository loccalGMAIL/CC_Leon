<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>GRUPO LEON S.A.</span></strong>. Todos los derechos reservados.
    </div>
    <div class="credits">
      Designed by <a target="_blank" href="https://pez.com.ar">Pez</a>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/shared/footer.blade.php ENDPATH**/ ?>