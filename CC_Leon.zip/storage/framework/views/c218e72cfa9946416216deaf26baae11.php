<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

  <main id="main" class="main">

    <div class="pagetitle">
    <h1>Proveedores - Camiones</h1>

    </div><!-- End Page Title -->

    <section class="section">
    <div class="row">
      <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
        <h5 class="card-title">Administrar los camiones</h5>
        <p class="card-text">En esta sección podrá administrar los camiones de los diferentes proveedores.</p>

        <a href="<?php echo e(route('proveedores.camiones.create')); ?>" class="btn btn-primary mt-3 mb-3">
          <i class="fa-solid fa-circle-plus"> </i> Agregar nuevo camión
        </a>
        <!-- Table with stripped rows -->
        <table class="table datatable">
          <thead>
          <tr>
            <th class="text-center">#</th>
            <th class="text-center">Patente</th>
            <th class="text-center">Proveedor</th>
            <th class="text-center">Fecha Creación</th>
            <th class="text-center">Acciones</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="text-center">
          <td><?php echo e($item->id); ?></td>
          <td><?php echo e($item->patente); ?></td>         
          <td><?php echo e($item->proveedor->nombreProveedor ?? 'Sin proveedor'); ?></td>
          <td><?php echo e($item->created_at); ?></td>
          <td>
          <a href="<?php echo e(route('proveedores.camiones.edit', $item->id)); ?>" class="btn btn-warning bt-sm"><i class="fa-solid fa-user-pen"></i></a>
          
          </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <!-- End Table with stripped rows -->

        </div>
      </div>

      </div>
    </div>
    </section>

  </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\CC_Leon\resources\views/modules/proveedores/camiones/index.blade.php ENDPATH**/ ?>